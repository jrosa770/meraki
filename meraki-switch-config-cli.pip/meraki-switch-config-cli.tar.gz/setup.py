from setuptools import setup, find_packages

setup(
    name="meraki-switch-config-cli",
    version="0.1.0",
    description="Backup and restore Cisco Meraki switch port configurations via CLI",
    author="Your Name",
    author_email="you@example.com",
    url="https://github.com/your-org/meraki-switch-config-cli",
    packages=find_packages(),
    install_requires=[
        "meraki>=1.45.0"
    ],
    entry_points={
        "console_scripts": [
            "meraki-switch-config=meraki_switch_config_cli:main",
        ]
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.7',
)