# Meraki Switch Config CLI

A simple CLI tool to **backup and restore** Cisco Meraki **switch port configurations**.

## Installation

```bash
pip install .
```

## Usage

```bash
meraki-switch-config --api-key <API_KEY> backup --serial <SWITCH_SERIAL>
meraki-switch-config --api-key <API_KEY> restore --serial <TARGET_SERIAL> --input <BACKUP_JSON>
```

MIT License