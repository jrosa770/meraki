from setuptools import setup, find_packages

setup(
    name="copy-meraki-network",
    version="0.1.0",
    description="Clone Meraki networks between organizations",
    author="Your Name",
    packages=find_packages(),
    install_requires=["meraki"],
    entry_points={"console_scripts": ["copy-meraki-network=copy_meraki_network.cli:main"]},
    python_requires=">=3.7",
)
