"""
cloner.py – core logic for copy-meraki-network
"""

from typing import Optional
import logging
import meraki
from meraki.exceptions import APIError

from .validators import validate_dhcp_settings

log = logging.getLogger("meraki-cloner")


# -------------------------------------------------------------------
# helpers
# -------------------------------------------------------------------
def setup_logging(level: str = "INFO") -> None:
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format="%(asctime)s %(levelname)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )


def _enable_vlans_if_needed(db, net_id: str) -> None:
    """Turn on VLANs if the destination network has them disabled."""
    try:
        st = db.appliance.getNetworkApplianceVlansSettings(net_id)
        if not st.get("vlansEnabled"):
            db.appliance.updateNetworkApplianceVlansSettings(
                networkId=net_id, vlansEnabled=True
            )
            log.info("Enabled VLANs on destination network %s", net_id)
    except APIError as exc:
        log.warning("Could not enable VLANs on %s: %s", net_id, exc)


# -------------------------------------------------------------------
# granular copy helpers
# -------------------------------------------------------------------
def _copy_vlans(db, src: str, dst: str) -> None:
    """Mirror VLAN + DHCP configuration from src to dst."""
    _enable_vlans_if_needed(db, dst)

    try:
        vlans = db.appliance.getNetworkApplianceVlans(src)
    except APIError as exc:
        log.warning("VLAN copy skipped: %s", exc)
        return

    for vlan in vlans:
        vid = vlan["id"]
        body = {k: v for k, v in vlan.items() if k not in ("id", "networkId")}

        try:
            db.appliance.updateNetworkApplianceVlan(
                networkId=dst, vlanId=vid, **body
            )
            log.info("✓ VLAN %s updated", vid)
        except APIError:
            db.appliance.createNetworkApplianceVlan(
                networkId=dst, id=vid, **body
            )
            log.info("✓ VLAN %s created", vid)


def _copy_ssids(db, src: str, dst: str) -> None:
    """Mirror basic SSID settings from src to dst."""
    try:
        ssids = db.wireless.getNetworkWirelessSsids(src)
    except APIError as exc:
        log.warning("SSID copy skipped: %s", exc)
        return

    for s in ssids:
        num = s["number"]
        body = {
            k: v
            for k, v in s.items()
            if k not in ("number", "networkId", "ssidAdminAccessible")
        }
        db.wireless.updateNetworkWirelessSsid(dst, num, **body)
        log.info("✓ SSID %d synced", num)


# -------------------------------------------------------------------
# public API
# -------------------------------------------------------------------
def clone_network(
    api_key: str,
    src_net_id: str,
    dst_org_id: str,
    *,
    dst_net_name: Optional[str] = None,
    time_zone: str = "America/Chicago",
    use_native: bool = True,
    log_level: str = "INFO",
) -> str:
    """
    Clone `src_net_id` into `dst_org_id`.

    Returns the newly created destination networkId.
    """
    setup_logging(log_level)
    db = meraki.DashboardAPI(api_key=api_key, print_console=False, suppress_logging=True)

    src_info = db.networks.getNetwork(src_net_id)
    log.info("Source '%s' (%s)", src_info["name"], src_net_id)

    # --------------------------------------------------------------- #
    # try native clone
    # --------------------------------------------------------------- #
    if use_native:
        try:
            dst = db.organizations.createOrganizationNetwork(
                organizationId=dst_org_id,
                name=dst_net_name or f"Cloned: {src_info['name']}",
                productTypes=src_info["productTypes"],
                timeZone=time_zone,
                copyFromNetworkId=src_net_id,
            )
            log.info("✓ Native clone succeeded (%s)", dst["id"])
            validate_dhcp_settings(db, src_net_id, dst["id"])
            return dst["id"]
        except APIError as exc:
            log.warning("Native clone failed: %s – falling back to granular copy", exc)

    # --------------------------------------------------------------- #
    # granular copy
    # --------------------------------------------------------------- #
    dst = db.organizations.createOrganizationNetwork(
        organizationId=dst_org_id,
        name=dst_net_name or f"Cloned: {src_info['name']}",
        productTypes=src_info["productTypes"],
        timeZone=time_zone,
    )
    new_id = dst["id"]
    log.info("Created blank network %s – starting granular sync", new_id)

    # copy components
    if "appliance" in src_info["productTypes"]:
        _copy_vlans(db, src_net_id, new_id)
    if "wireless" in src_info["productTypes"]:
        _copy_ssids(db, src_net_id, new_id)

    validate_dhcp_settings(db, src_net_id, new_id)
    log.info("Granular sync complete ✓")
    return new_id
