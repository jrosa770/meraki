import argparse
from .cloner import clone_network

def main() -> None:
    p = argparse.ArgumentParser(description="Clone a Meraki network across orgs")
    p.add_argument("--api-key", required=True, help="Dashboard API key")
    p.add_argument("--src-net", required=True, help="Source network ID")
    p.add_argument("--dst-org", required=True, help="Destination org ID")
    p.add_argument("--dst-name", help="Destination network name")
    p.add_argument("--time-zone", default="America/Chicago")
    p.add_argument("--no-native", action="store_true",
                   help="Force granular copy (skip native clone)")
    p.add_argument("--log-level", default="INFO")
    args = p.parse_args()

    new_id = clone_network(
        api_key=args.api_key,
        src_net_id=args.src_net,
        dst_org_id=args.dst_org,
        dst_net_name=args.dst_name,
        time_zone=args.time_zone,
        use_native=not args.no_native,
        log_level=args.log_level,
    )
    print(f"✓ Network cloned to {new_id}")
