import logging
from meraki.exceptions import APIError

log = logging.getLogger("meraki-cloner")


def _vlans_enabled(db, net_id: str) -> bool:
    try:
        st = db.appliance.getNetworkApplianceVlansSettings(net_id)
        return st.get("vlansEnabled", False)
    except APIError:
        return False

def validate_dhcp_settings(db, src_net, dst_net, auto_fix=True):
    try:
        src_vlans = db.appliance.getNetworkApplianceVlans(src_net)
        dst_vlans = db.appliance.getNetworkApplianceVlans(dst_net)
    except APIError as e:
        log.warning("DHCP validation skipped: %s", e)
        return

    report_lines = ["DHCP Validation Report:\n"]
    src_map = {v["id"]: v for v in src_vlans}
    dst_map = {v["id"]: v for v in dst_vlans}

    for vlan_id, src_vlan in src_map.items():
        dst_vlan = dst_map.get(vlan_id)
        if not dst_vlan:
            msg = f"✗ VLAN {vlan_id} ({src_vlan.get('name')}) missing in destination"
            log.warning(msg)
            report_lines.append(msg)
            continue

        fields = ["subnet", "applianceIp", "dhcpHandling", "dhcpLeaseTime", "dnsNameservers", "dhcpOptions"]
        mismatches = [f for f in fields if src_vlan.get(f) != dst_vlan.get(f)]

        if mismatches:
            msg = f"✗ VLAN {vlan_id} ({src_vlan.get('name')}) DHCP mismatch: {', '.join(mismatches)}"
            log.warning(msg)
            report_lines.append(msg)

            if auto_fix:
                patch = {f: src_vlan.get(f) for f in mismatches}
                try:
                    db.appliance.updateNetworkApplianceVlan(
                        networkId=dst_net,
                        vlanId=vlan_id,
                        **patch
                    )
                    fix_msg = f"✓ Auto-corrected VLAN {vlan_id} → {', '.join(patch.keys())}"
                    log.info(fix_msg)
                    report_lines.append(fix_msg)
                except APIError as e:
                    err_msg = f"✗ Failed to auto-correct VLAN {vlan_id}: {e}"
                    log.error(err_msg)
                    report_lines.append(err_msg)
        else:
            msg = f"✓ VLAN {vlan_id} ({src_vlan.get('name')}) DHCP validated"
            log.info(msg)
            report_lines.append(msg)

    report_path = f"dhcp_validation_report_{dst_net}.txt"
    with open(report_path, "w") as f:
        f.write("\n".join(report_lines))
    log.info("Validation report saved to %s", report_path)