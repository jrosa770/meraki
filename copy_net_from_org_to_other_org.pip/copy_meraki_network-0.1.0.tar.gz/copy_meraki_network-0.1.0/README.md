# Copy Meraki Network

CLI + library for cloning a Meraki Dashboard network (VLANs, DHCP scopes, SSIDs)
from one organization into another, with optional validation reports.
