from copy_meraki_network.validators import validate_dhcp_settings

def test_dhcp_validation(tmp_path, mock_api):
    validate_dhcp_settings(mock_api, "src", "dst")
    assert (tmp_path / "dhcp_validation_report_dst.txt").exists() is False
