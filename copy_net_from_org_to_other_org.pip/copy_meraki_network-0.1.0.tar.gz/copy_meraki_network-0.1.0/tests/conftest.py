import pytest
from unittest.mock import MagicMock

@pytest.fixture
def mock_api():
    api = MagicMock()
    api.appliance.getNetworkApplianceVlansSettings.return_value = {"vlansEnabled": True}
    api.appliance.getNetworkApplianceVlans.side_effect = [
        [{"id": "10", "name": "VLAN10", "subnet": "10.0.10.0/24", "applianceIp": "10.0.10.1",
          "dhcpHandling": "Run a DHCP server", "dhcpLeaseTime": 86400,
          "dnsNameservers": "default", "dhcpOptions": []}],
        [{"id": "10", "name": "VLAN10", "subnet": "10.0.10.0/24", "applianceIp": "10.0.10.1",
          "dhcpHandling": "Run a DHCP server", "dhcpLeaseTime": 86400,
          "dnsNameservers": "default", "dhcpOptions": []}],
    ]
    return api

